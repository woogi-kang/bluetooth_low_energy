//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<bluetooth_low_energy_darwin/BluetoothLowEnergyDarwinPlugin.h>)
#import <bluetooth_low_energy_darwin/BluetoothLowEnergyDarwinPlugin.h>
#else
@import bluetooth_low_energy_darwin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BluetoothLowEnergyDarwinPlugin registerWithRegistrar:[registry registrarForPlugin:@"BluetoothLowEnergyDarwinPlugin"]];
}

@end

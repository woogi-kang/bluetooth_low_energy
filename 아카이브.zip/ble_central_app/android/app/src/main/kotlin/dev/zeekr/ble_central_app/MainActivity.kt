package dev.zeekr.ble_central_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
package dev.zeekr.bluetooth_low_energy_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

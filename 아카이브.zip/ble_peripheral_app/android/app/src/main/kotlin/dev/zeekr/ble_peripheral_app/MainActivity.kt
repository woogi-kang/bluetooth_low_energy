package dev.zeekr.ble_peripheral_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
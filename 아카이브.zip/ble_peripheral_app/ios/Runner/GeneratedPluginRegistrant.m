//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<bluetooth_low_energy_darwin/BluetoothLowEnergyDarwinPlugin.h>)
#import <bluetooth_low_energy_darwin/BluetoothLowEnergyDarwinPlugin.h>
#else
@import bluetooth_low_energy_darwin;
#endif

#if __has_include(<record_ios/RecordIosPlugin.h>)
#import <record_ios/RecordIosPlugin.h>
#else
@import record_ios;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BluetoothLowEnergyDarwinPlugin registerWithRegistrar:[registry registrarForPlugin:@"BluetoothLowEnergyDarwinPlugin"]];
  [RecordIosPlugin registerWithRegistrar:[registry registrarForPlugin:@"RecordIosPlugin"]];
}

@end

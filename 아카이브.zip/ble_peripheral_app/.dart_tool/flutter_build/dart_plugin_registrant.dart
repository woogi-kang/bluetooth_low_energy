//
// Generated file. Do not edit.
// This file is generated from template in file `flutter_tools/lib/src/flutter_plugins.dart`.
//

// @dart = 3.7

import 'dart:io'; // flutter_ignore: dart_io_import.
import 'package:bluetooth_low_energy_android/bluetooth_low_energy_android.dart';
import 'package:bluetooth_low_energy_darwin/bluetooth_low_energy_darwin.dart';
import 'package:bluetooth_low_energy_linux/bluetooth_low_energy_linux.dart';
import 'package:record_linux/record_linux.dart';
import 'package:bluetooth_low_energy_darwin/bluetooth_low_energy_darwin.dart';
import 'package:bluetooth_low_energy_windows/bluetooth_low_energy_windows.dart';

@pragma('vm:entry-point')
class _PluginRegistrant {

  @pragma('vm:entry-point')
  static void register() {
    if (Platform.isAndroid) {
      try {
        BluetoothLowEnergyAndroidPlugin.registerWith();
      } catch (err) {
        print(
          '`bluetooth_low_energy_android` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isIOS) {
      try {
        BluetoothLowEnergyDarwinPlugin.registerWith();
      } catch (err) {
        print(
          '`bluetooth_low_energy_darwin` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isLinux) {
      try {
        BluetoothLowEnergyLinuxPlugin.registerWith();
      } catch (err) {
        print(
          '`bluetooth_low_energy_linux` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

      try {
        RecordLinux.registerWith();
      } catch (err) {
        print(
          '`record_linux` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isMacOS) {
      try {
        BluetoothLowEnergyDarwinPlugin.registerWith();
      } catch (err) {
        print(
          '`bluetooth_low_energy_darwin` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isWindows) {
      try {
        BluetoothLowEnergyWindowsPlugin.registerWith();
      } catch (err) {
        print(
          '`bluetooth_low_energy_windows` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    }
  }
}
